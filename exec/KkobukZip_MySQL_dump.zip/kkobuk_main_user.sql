-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11c107.p.ssafy.io    Database: kkobuk_main
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_date` datetime(6) DEFAULT NULL,
  `last_modified_date` datetime(6) DEFAULT NULL,
  `address` varchar(255) NOT NULL,
  `birth` date NOT NULL,
  `email` varchar(255) NOT NULL,
  `foreign_flag` bit(1) NOT NULL,
  `name` varchar(255) NOT NULL,
  `nickname` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phonenumber` varchar(255) NOT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `role` enum('ROLE_ADMIN','ROLE_USER') NOT NULL,
  `uuid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'2024-10-04 08:55:26.143177','2024-10-04 08:55:26.143177','전남 순천시 서면 판교리 14 / 길거리','1990-12-11','test1@gmail.com',_binary '\0','asdf','거북이 최고야','$2a$10$.BqI8sDxyTruepStEpW2ZeQClzPNR80Sn9cgmGKV.D2nY61cjg2ji','010-1234-1234','https://s11p21c107-ssafy-special-project.s3.amazonaws.com/user/d6f96d05-906e-4e9f-b7b7-bb2ff6ac6e39_dog-3397110_1280.jpg','ROLE_USER','b7ee1493-2f1f-44e1-adc5-5634d897bf0c'),(2,'2024-10-04 09:36:41.034635','2024-10-04 11:13:50.778292','행복한 싸피 / 길바닥','1990-12-11','testuser@example.com',_binary '\0','싸피갓','싸피 거북','$2a$10$yane1f8VbTrp8kcoDlj9dOUqN0zBAKdjbPH9McxjjIt1rVZf/suSa','010-1234-1234','https://s11p21c107-ssafy-special-project.s3.amazonaws.com/user/697709f0-de02-40f0-8f43-ccaa63091961_profile14.gif','ROLE_USER','a4495143-fc82-41ba-abae-ce39addf13a6'),(3,NULL,'2024-10-11 05:00:03.086758','Test Address','1990-01-01','test@test.com',_binary '\0','Test Name','꼬북집','$2b$12$HCHpXacVlT3lESKFVoYRDOebt8S7PGW3BqLNYHf0TlUiW1l9RARZO','010-1234-5678','https://d2jcuikzdl8qty.cloudfront.net/user/04289956-518a-430f-bff9-aa500575e971_profile10.gif','ROLE_USER','some-uuid-value'),(4,NULL,NULL,'Admin Address','1985-05-15','admin@admin.com',_binary '\0','Admin User','admin_nickname','$2b$12$ly1ex5ro5S.E9HvADQQTROR1VEzKW8U4hZ40yVoKd/jS/UX5jB0sC','010-9876-5432',NULL,'ROLE_ADMIN','admin-uuid-value'),(5,'2024-10-04 15:10:41.698489','2024-10-07 09:59:05.794338','123 Example Street','1990-01-01','example@example.com',_binary '\0','Example Name','exampleNickname','$2a$10$BLpeZf0PBy5AUZ.QFPVM4.ltKNuzMUZZYNpp9NeVgDqh97/4XjRjq','010-1234-5678','https://s11p21c107-ssafy-special-project.s3.amazonaws.com/user/4475c45c-799c-4dbf-a65d-d25eec2b21e2_profile13.gif','ROLE_USER','348c1474-2fbf-44c3-b5d9-02eb32c3c0ce'),(6,'2024-10-05 21:16:16.432045','2024-10-05 21:16:16.432045','광주 광산구 첨단중앙로181번길 88-21 / 999동 9999호','1998-09-16','seo980916@gmail.com',_binary '\0','서규범','구스범스','$2a$10$jOq0dru06al.fbEF8ilyLe1cVIJHuM5hMQMcQwG635sx.FWqDjgCe','010-3812-9816','https://s11p21c107-ssafy-special-project.s3.amazonaws.com/user/514afb68-c3dd-4d81-b099-088c99590a46_profile11.gif','ROLE_USER','1e2bf41f-2a67-4817-bf47-42f63b31ba29'),(7,'2024-10-07 10:47:19.704803','2024-10-11 09:18:55.165164','서울 강남구 테헤란로 212 / 광주캠','2024-02-12','kkobukzip@gmail.com',_binary '\0','꼬부기','꼬북꼬북','$2a$10$6qYvI/zAN4ZCHTU7RwApK.jjqlkvT13MUCYnfkwSxq49QjjRqv1cy','010-1234-5678','https://d2jcuikzdl8qty.cloudfront.net/user/4394c7fa-de88-4de7-814d-9a9b28739e06_profile14.gif','ROLE_USER','327d1d59-9138-4891-b8c5-b0e7afce4126'),(8,NULL,NULL,'123 Test St, Test City','1990-01-01','test1@test.com',_binary '\0','테스트','testUser1','$2b$12$UeQg5/PyXvom/8/Mx9fdKeIRNErX4o49L8dXZhP7vpt7e4MRcq/M.','010-1234-5678',NULL,'ROLE_USER','3fa85f64-5717-4562-b3fc-2c963f66afa6'),(9,'2024-10-07 15:54:49.441916','2024-10-07 15:54:49.441916','전남 보성군 벌교읍 벌교마동길 46 / 왕년엔 나도 벌처왕','1999-11-11','atdark04@gmail.com',_binary '\0','asdfqwer!!','싸피에서 사는 거북이','$2a$10$WBJ9jSSqSD879MZ58IuRu.olCFz1uMkJFj5UwmojMboE5os3O3qUu','010-1234-1234','https://s11p21c107-ssafy-special-project.s3.amazonaws.com/user/f280fbb5-25ce-4abd-bcd5-781488a2a067_profile3.gif','ROLE_USER','3f6ae0c0-0bc4-43a6-afa1-ec03febe7734'),(10,'2024-10-07 23:12:24.147586','2024-10-07 23:12:24.147586','123 Example Street','1990-01-01','ssafy@ssafy.com',_binary '\0','Example Name','exampleNickname','$2a$10$Tm1QoPB6gHOt/bCAFmOfcuZSncyez7VPlxhp5MpZRxxX37RtgM6ju','010-1234-5678','https://s11p21c107-ssafy-special-project.s3.amazonaws.com/user/c6057bd4-2f3b-4fce-bf72-efd546ac41f1_%EC%BD%94%EC%8A%A4%EB%AA%A8.jpg','ROLE_USER','b669edc5-4ed2-4735-aa0a-21b6a7a9482f'),(11,'2024-10-08 16:31:20.763318','2024-10-08 16:31:20.763318','서울 강남구 테헤란로 212 / 광주캠','2001-01-10','tlsalsrud252@naver.com',_binary '\0','테스트꼬부기','꼬북꼬북','$2a$10$zKdYiI8qwXYVRDOLrwuMleOkahclGMngtm1WeJO7K80Lh2hmVWNQi','010-1111-1111','https://s11p21c107-ssafy-special-project.s3.amazonaws.com/user/e351b8ba-031b-4732-b5fa-0039b2e89f06_profile12.gif','ROLE_USER','317e3697-b6fa-4a38-be1e-b8169ba49a46'),(12,'2024-10-10 13:25:19.345824','2024-10-10 13:25:19.345824','서울 강남구 강남대로 238 / ㅁㄴㄹㄴㅁㅇㄹ','1999-03-17','kyb031700@naver.com',_binary '\0','빈빈빈','빈빈빈','$2a$10$4wjMWqQ4FtFroNY/SrVoe.hLNPMwG93ZZZbBHnZ1.8bI.cdhLcMVa','010-1111-1231','https://d2jcuikzdl8qty.cloudfront.net/user/b4cc4f83-b014-4884-9e3a-e5e5ccfc53fc_profile6.gif','ROLE_USER','bde7a781-053c-4b4b-bea8-f097e60a13c6'),(13,'2024-10-10 19:40:56.289495','2024-10-10 19:42:17.134753','광주 광산구 마항길 26 / 영빈이네집','1998-09-14','gnsals0904@naver.com',_binary '\0','훈민','훈민','$2a$10$AOK2xLTHtxkBSBupJ/5tr.D4FkBKaw5OGzh0UZLcidKBlBQ1QAC3S','010-5228-9804','https://d2jcuikzdl8qty.cloudfront.net/user/230cea7f-8ff2-4be0-a6d0-2115709295cc_profile5.gif','ROLE_USER','070b2ab1-63c5-4c7e-8abd-0d77eef1a3e7'),(14,'2024-10-10 20:08:10.332818','2024-10-10 20:08:10.332818','경기 성남시 분당구 경부고속도로 409 / 분당에 바람이 분당','1999-01-01','t@e.st',_binary '\0','김싸피','김싸피','$2a$10$Vjo.rbVkPTTkqYTOeEUxQOF6.MULCuZSRqZYQB.zrG8lCN47SAZ3q','010-1221-1221','https://d2jcuikzdl8qty.cloudfront.net/user/3ea23dbe-fdf1-4ac0-8415-ca4d2f2fc26e_profile14.gif','ROLE_USER','41653f16-c77d-4c47-94e2-83e043a5780e'),(15,'2024-10-10 20:35:26.935622','2024-10-10 20:35:26.935622','서울 은평구 가좌로12길 20 / 1','1233-12-31','asdf@a.com',_binary '','asdf','asdf','$2a$10$kDLtctCoWLVKOWK39l4rbOdOuRUXTXwi7Pr765lBDRRlKyJSsjve2','123-1231-1232','https://d2jcuikzdl8qty.cloudfront.net/user/c08f12b8-8a98-4e96-9c94-71b3b81fe780_profile10.gif','ROLE_USER','6e66bbb7-acb2-4c20-9563-73ed7c50475e'),(16,'2024-10-10 21:01:19.109284','2024-10-10 21:01:19.109284','광주 광산구 임방울대로 338 / 엔제리너스','1234-05-06','a@s.d',_binary '\0','haha','hoho','$2a$10$eHrAUTzKVLvlHYCRKSxss.t936vRwcpZq.u/yf2BGp4imBNDm/E2S','010-1010-1010','https://d2jcuikzdl8qty.cloudfront.net/user/ae2bd04d-98d2-4814-98c1-a27fd85fba46_profile11.gif','ROLE_USER','3f9c34f8-69af-446b-811e-14703a12b2d4'),(17,'2024-10-10 21:05:21.002371','2024-10-10 21:05:21.002371','광주 광산구 임방울대로 338 / 엔제리너스','1234-05-06','q@w.e',_binary '\0','hihi','hehe','$2a$10$Y7f52oHO.urHkSUCFGsEOOE7kC5ADtKC3Wg/h8eJU2WBK.I/YoOZe','010-0101-0101','https://d2jcuikzdl8qty.cloudfront.net/user/8b283540-2511-4885-89db-0983fc9efdc6_profile12.gif','ROLE_USER','93ad814a-f09c-430b-8e04-6c3734205577');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-11  9:49:07
