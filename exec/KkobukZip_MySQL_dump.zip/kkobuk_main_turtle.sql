-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11c107.p.ssafy.io    Database: kkobuk_main
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `turtle`
--

DROP TABLE IF EXISTS `turtle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `turtle` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_date` datetime(6) DEFAULT NULL,
  `last_modified_date` datetime(6) DEFAULT NULL,
  `birth` date NOT NULL,
  `dead` bit(1) NOT NULL,
  `gender` enum('FEMALE','MALE') NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `scientific_name` varchar(255) NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `weight` int NOT NULL,
  `dad_id` bigint DEFAULT NULL,
  `mom_id` bigint DEFAULT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKa9r7i2d6xoh8q7lvfhb4hqc7w` (`dad_id`),
  KEY `FK2mvoq388aqq74eee9s3jth09n` (`mom_id`),
  KEY `FKc8qx36iaf4yi2di1i84osqyr0` (`user_id`),
  CONSTRAINT `FK2mvoq388aqq74eee9s3jth09n` FOREIGN KEY (`mom_id`) REFERENCES `turtle` (`id`),
  CONSTRAINT `FKa9r7i2d6xoh8q7lvfhb4hqc7w` FOREIGN KEY (`dad_id`) REFERENCES `turtle` (`id`),
  CONSTRAINT `FKc8qx36iaf4yi2di1i84osqyr0` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `turtle`
--

LOCK TABLES `turtle` WRITE;
/*!40000 ALTER TABLE `turtle` DISABLE KEYS */;
INSERT INTO `turtle` VALUES (18,'2024-10-09 23:55:15.765522','2024-10-09 23:55:15.765522','1999-01-01',_binary '\0','MALE','대모','Malaclemys terrapin','UUID-1',100,NULL,NULL,3),(19,'2024-10-09 23:55:15.765522','2024-10-09 23:55:15.765522','1999-01-01',_binary '\0','FEMALE','대모','Malaclemys terrapin','UUID-2',100,NULL,NULL,3),(20,'2024-10-09 23:55:15.765522','2024-10-10 00:18:53.919711','2024-01-02',_binary '\0','MALE','파랑이','Malaclemys terrapin','b26b9a65-e151-488c-b19a-9cb99ba2f7b1',135,18,19,6),(21,'2024-10-10 00:04:48.026146','2024-10-10 14:06:15.320489','2024-02-01',_binary '\0','FEMALE','푸른이','Malaclemys terrapasfdin','518e041c-4f92-4e61-855c-db784089512e',234123,18,19,6),(22,'2024-10-10 14:09:00.586154','2024-10-10 14:09:00.586154','1998-12-05',_binary '\0','MALE','겁욱왕','Malaclemys terrapin','1872f00f-f351-44f5-90b3-208c4b984804',5,18,19,3),(23,'2024-10-10 14:43:42.579821','2024-10-10 14:43:42.579821','2024-10-23',_binary '\0','MALE','거북','Malaclemys terrapin','0877c106-9043-4b52-a58d-821b75b7535f',1,18,19,3),(24,'2024-10-10 16:19:40.751073','2024-10-10 17:04:27.548307','2024-10-10',_binary '\0','MALE','꼬북꼬북','Malaclemys terrapin','73308b12-c408-4241-9706-a1cbe2328210',100,18,19,11),(27,'2024-10-10 21:49:26.925634','2024-10-10 21:49:26.925634','2023-11-11',_binary '\0','MALE','아쿠아','Malaclemys terrapin','a1d52018-c13a-454e-9993-14aea5510aa9',2451,18,19,7),(30,'2024-10-10 22:01:22.429627','2024-10-11 09:21:51.482000','2023-11-11',_binary '\0','MALE','테라','Malaclemys terrapin','98ad9336-d64e-472c-8bb7-89c78cd2043d',200,18,19,6),(34,'2024-10-10 23:47:29.825510','2024-10-10 23:47:29.825510','2023-11-11',_binary '\0','FEMALE','녹색이','Malaclemys terrapin','5e5f4c7f-c73d-424a-bf84-e698ae4b0225',1111,18,19,7),(35,'2024-10-10 23:49:27.237059','2024-10-10 23:49:27.237059','2024-01-01',_binary '\0','FEMALE','꼬북코인','Malaclemys terrapin','5d645813-bad5-4682-8c95-cd6bf70a09c7',123,18,19,7),(38,'2024-10-11 09:19:25.741370','2024-10-11 09:19:25.741370','2023-10-21',_binary '\0','MALE','삼성이','Malaclemys terrapin','2481dbb9-e398-4deb-9f8e-79c82a9b92ed',8741,27,34,7);
/*!40000 ALTER TABLE `turtle` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-11  9:49:08
