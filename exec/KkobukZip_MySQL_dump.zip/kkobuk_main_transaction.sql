-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11c107.p.ssafy.io    Database: kkobuk_main
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_date` datetime(6) DEFAULT NULL,
  `last_modified_date` datetime(6) DEFAULT NULL,
  `auction_flag` bit(1) DEFAULT NULL,
  `buyer_id` bigint DEFAULT NULL,
  `content` varchar(255) NOT NULL,
  `document_hash` varchar(255) DEFAULT NULL,
  `price` double NOT NULL,
  `progress` enum('APPROVED_DOCUMENT','COMPLETED','REVIEW_DOCUMENT','SAIL') NOT NULL,
  `seller_address` varchar(255) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `weight` int NOT NULL,
  `turtle_id` bigint DEFAULT NULL,
  `buyer_uuid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKdw4lmq6ajep6nvq3nwh5swm85` (`turtle_id`),
  CONSTRAINT `FKdw4lmq6ajep6nvq3nwh5swm85` FOREIGN KEY (`turtle_id`) REFERENCES `turtle` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction`
--

LOCK TABLES `transaction` WRITE;
/*!40000 ALTER TABLE `transaction` DISABLE KEYS */;
INSERT INTO `transaction` VALUES (61,'2024-10-11 02:29:11.342118','2024-10-11 09:21:51.492528',_binary '\0',6,'팔게요~','2D702B70F73AF9E471DE833AE80BD25A5C252A7E3D377B1C716C170ADEE839E4',100,'COMPLETED','0x10F0846C49cfDf0d0B226C88f027a9F66306E4Cd','테라 팔아요',0,30,'1e2bf41f-2a67-4817-bf47-42f63b31ba29'),(62,'2024-10-11 09:20:06.968834','2024-10-11 09:20:50.826702',_binary '\0',6,'팔아요',NULL,100,'REVIEW_DOCUMENT','0x10F0846C49cfDf0d0B226C88f027a9F66306E4Cd','삼성이 팔아요',0,38,'1e2bf41f-2a67-4817-bf47-42f63b31ba29'),(63,'2024-10-11 09:23:34.640540','2024-10-11 09:23:34.640540',_binary '',12,'팝니다',NULL,10100,'SAIL','0x10F0846C49cfDf0d0B226C88f027a9F66306E4Cd','경매해요',100,35,'bde7a781-053c-4b4b-bea8-f097e60a13c6');
/*!40000 ALTER TABLE `transaction` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-11  9:49:07
