-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11c107.p.ssafy.io    Database: kkobuk_main
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `turtle_photo`
--

DROP TABLE IF EXISTS `turtle_photo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `turtle_photo` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_date` datetime(6) DEFAULT NULL,
  `last_modified_date` datetime(6) DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `turtle_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKh0px4rkjl3k923cvul9smypc3` (`turtle_id`),
  CONSTRAINT `FKh0px4rkjl3k923cvul9smypc3` FOREIGN KEY (`turtle_id`) REFERENCES `turtle` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `turtle_photo`
--

LOCK TABLES `turtle_photo` WRITE;
/*!40000 ALTER TABLE `turtle_photo` DISABLE KEYS */;
INSERT INTO `turtle_photo` VALUES (1,'2022-05-14 14:23:45.123456','2024-09-20 14:23:45.123456','https://d2jcuikzdl8qty.cloudfront.net/turtle/terrpin1.jpg',18),(2,'2022-05-14 14:23:45.123456','2024-09-20 14:23:45.123456','https://d2jcuikzdl8qty.cloudfront.net/turtle/terrpin2.jpg',19),(3,'2022-05-14 14:23:45.123456','2024-09-20 14:23:45.123456','https://d2jcuikzdl8qty.cloudfront.net/turtle/terrpin3.jpg',20),(4,'2022-05-14 14:23:45.123456','2024-09-20 14:23:45.123456','https://d2jcuikzdl8qty.cloudfront.net/turtle/turtle5.jpg',21),(5,'2024-10-10 14:09:00.590411','2024-10-10 14:09:00.590411','https://d2jcuikzdl8qty.cloudfront.net/turtle/turtle6.jpg',22),(6,'2024-10-10 14:43:42.590344','2024-10-10 14:43:42.590344','https://d2jcuikzdl8qty.cloudfront.net/turtle/terrpin2.jpg',23),(7,'2024-10-10 16:19:40.772487','2024-10-10 16:19:40.772487','https://d2jcuikzdl8qty.cloudfront.net/turtle/terrpin4.jpg',24),(8,'2024-10-10 21:42:40.952967','2024-10-10 21:42:40.952967','https://d2jcuikzdl8qty.cloudfront.net/turtle/terrpin2.jpg',25),(9,'2024-10-10 21:49:17.631597','2024-10-10 21:49:17.631597','https://d2jcuikzdl8qty.cloudfront.net/turtle/terrpin2.jpg',26),(10,'2024-10-10 21:49:26.928299','2024-10-10 21:49:26.928299','https://d2jcuikzdl8qty.cloudfront.net/turtle/turtle1.jpg',27),(11,'2024-10-10 21:49:36.821757','2024-10-10 21:49:36.821757','https://d2jcuikzdl8qty.cloudfront.net/turtle/terrpin4.jpg',28),(12,'2024-10-10 21:49:45.878758','2024-10-10 21:49:45.878758','https://d2jcuikzdl8qty.cloudfront.net/turtle/terrpin4.jpg',29),(13,'2024-10-10 22:01:22.431752','2024-10-10 22:01:22.431752','https://d2jcuikzdl8qty.cloudfront.net/turtle/turtle2.jpg',30),(14,'2024-10-10 22:33:26.840453','2024-10-10 22:33:26.840453','https://d2jcuikzdl8qty.cloudfront.net/turtle/terrpin2.jpg',31),(15,'2024-10-10 22:33:53.446256','2024-10-10 22:33:53.446256','https://d2jcuikzdl8qty.cloudfront.net/turtle/terrpin2.jpg',32),(16,'2024-10-10 23:47:17.775801','2024-10-10 23:47:17.775801','https://d2jcuikzdl8qty.cloudfront.net/turtle/terrpin6.jpg',33),(17,'2024-10-10 23:47:29.827729','2024-10-10 23:47:29.827729','https://d2jcuikzdl8qty.cloudfront.net/turtle/turtle3.jpg',34),(18,'2024-10-10 23:49:27.239263','2024-10-10 23:49:27.239263','https://d2jcuikzdl8qty.cloudfront.net/turtle/turtle4.jpg',35),(19,'2024-10-11 01:49:57.772812','2024-10-11 01:49:57.772812','https://d2jcuikzdl8qty.cloudfront.net/turtle/terrpin3.jpg',36),(20,'2024-10-11 02:13:05.701424','2024-10-11 02:13:05.701424','https://d2jcuikzdl8qty.cloudfront.net/turtle/terrpin1.jpg',37),(21,'2024-10-11 09:19:25.743495','2024-10-11 09:19:25.743495','https://d2jcuikzdl8qty.cloudfront.net/turtle/terrpin4.jpg',38);
/*!40000 ALTER TABLE `turtle_photo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-11  9:49:08
